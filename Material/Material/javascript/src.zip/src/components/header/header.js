import './header.css';

export function Header(){

  function login(){


  }

  function signup(){


  }

  let style = {
        flex:{
          backgroundColor:"magenta"
        },
        box:{
          width:"100px",
          height:"100px"
        }
  }
  
//   npm uninstall jquery
//   npm install react-router-dom@Header
//   npm uninstall react-router-dom
//   npm update react-router-dom

//   npm ls react-router-dom

// node package manager
// library installer h just


  let city = "Faisalabad";

    return  <nav style={style.flex}>
      <h1>{city}</h1>
      <div onClick={signup}>adsasd</div>
    <div class="nav-wrapper">
      <a href="#" class="brand-logo">Logo</a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="sass.html">Sass</a></li>
        <li><a href="badges.html">Components</a></li>
        <li><a href="collapsible.html">JavaScript</a></li>
      </ul>
    </div>
  </nav>
}

