import { Parent } from "./gamica";

import  ReactDOM from "react-dom";


ReactDOM.render(<div>
                    <Parent />
                  
                </div>, document.getElementById('fsd1') );



