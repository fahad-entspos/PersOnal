
import {useRef, useEffect, useState} from 'react';
import TableList from './components/tableList/tableList';
import UserSignup from './components/userSignup/userSignup';

// let meraNumber = 50;


function Baby(props){

  return <h1>{props.cname.name}</h1>;

}

function Cities(props){

  // let cities = ["FSD", "LHR", "MUL"];

  return <div>
    <Baby cname={props}></Baby>
    <ol>
      {
        props.b1.map((city)=>{
          return <li>{city}</li>
        })
      }
    </ol>
  </div>;

}

// programming patterns
// / MVVM
// MODEL VIEW VIEW MODEL
// MVC
// MoDEL VIEW CONTROLLER
// SHadow DOM
export function Parent(){

  // let [num, setNum] = useState(10);
  let [users, setUsers] = useState([]);

  return <div>  

     <UserSignup users={users} abc={setUsers}></UserSignup>
   
    <TableList users={users} setUsers={setUsers}></TableList>
 
  </div>

  }

// export function Parent(){

//   let [num, setNum] = useState(20);

//   let [num1, setNum1] = useState(50);
//   // let num = 20;

//   return <div> 
//     <input type="text" />

//     <h1>{num}</h1>   
//     <h1>{num1}</h1>   
    

//   <button onClick={function(){
    
//     setNum(++num);

//   }}>NUmber 1</button>

//   <button onClick={function(){

//   num1++;
//   setNum1(num1);

//   }}>NUmber 2</button>

// </div>;

// }

// let data = [
//   {
//     name:"ahmed",
//     subjects:[
//       {
//         category:"science",
//         items:["chemistry", "biology"]
//       }
//     ]
//   },
//   {
//     name:"noor",
//     subjects:[
//       {
//         category:"Arts",
//         items:["English", "Urdu"]
//       }
//     ]
//   },
//   {
//     name:"farhan",
//     subjects:[
//       {
//         category:"science",
//         items:["Physics", "Chemistry"]
//       }
//     ]
//   }
// ];

// function Media(){

//   return <div>
//       <Media></Media>
//   </div>

// }