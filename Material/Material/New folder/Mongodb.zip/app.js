    let express = require('express');

    let mongoose = require('mongoose');

    let User =  require('./db/models/user');

    mongoose.connect('mongodb://localhost:27017/studentWaliDB', (err, connection)=>{

    if(connection){


        console.log("DB chal paring");

    //     let nyaUser = new User();
    //     nyaUser.name = "faizan";
    //     nyaUser.age = 20;
    //     nyaUser.subjects = ['english', 'physics', 'chemistry'];
    //    nyaUser.passedout = true;
    //    nyaUser.save();
       

    }else{
        console.log("msla wa");
    }



    });







    let app = express();
    app.use(express.json());


    let jsonwebtoken = require('jsonwebtoken');


    let fs = require('fs');

    // fs.existsSync()

    // fs.writeFile('server/cat.txt', "mioon", (err)=>{
    //     console.log(err);
    // })

    // fs.unlink("server/build.zip", (err)=>{
    //     console.log(err);
    // })

// fs.mkdir("server/testing", (err, data)=>{
//     console.log(err || data);

// });


    const multer  = require('multer');

    const storage = multer.diskStorage({
        destination: function (req, file, cb) {

            let destination  = "server/hello/"+req.body.name;

          let folderH =   fs.existsSync(destination);

            if(folderH){

                cb({message:"User already h"}, null)

            }else{

                fs.mkdir(destination, (err)=>{

                    cb(null, destination)
    
                })


            }

            


            




        },
        filename: function (req, file, cb) {          
          cb(null, file.originalname)
        }
      })
      
      const upload = multer({ storage: storage })
      

    
    let users = [];

    app.get('/session-check-karo', async (req, res)=>{

        try{

            let data = await jsonwebtoken.verify(req.query.tk, "FSD m cat says mioon")
            
            let user = users.find(user=>user.id == data.id);
            
            res.json(user);
        }catch(e){
            res.json(null);
        }

        


    });
    
    app.post('/login', (req, res)=>{

       let user =  users.find((user)=>{

                    if(user.name == req.body.name && user.password == req.body.password){
                        return true;
                    }
        
                });

                if(user){

                jsonwebtoken.sign({
                    id:user.id
                },"FSD m cat says mioon", {
                    expiresIn:"2h"
                }, (err, meraToken)=>{


                    res.json({
                        token:meraToken,
                        meraUser:user
                    });



                })

            }else{
                res.json(null);
            }


    });

    app.get('/users-lao', async (req, res)=>{
        
let users = await User.find({name:"faizan", age:{$gt:50}});
        
        res.json(users);
        
    })
    // REST API
    // axios.get()
    // axios.put()
    // axios.delete()
    

    app.get('/user-find-karo', (req, res)=>{

        let userMilgya =  users.find(function(user, index){

            if(user.name == req.query.name){                 
                 return true;
             }
 
         });

         res.json(userMilgya);

    })

    app.put('/user-update-karo', (req, res)=>{

        let milgya = users.findIndex(user=>user.id == req.body.id);
        users[milgya] = req.body;

    })
    
    app.delete('/delete-karo', (req, res)=>{
      
        users.splice(  req.query.meraIndex, 1);

        res.json({
            success:true
            }
        )

        console.log("deeted")
    });
    
    app.post('/signup-karo',upload.single('file') , (req, res)=>{
        


        let nyaUser = new User(req.body);
    //     nyaUser.name = "faizan";
    //     nyaUser.age = 20;
    //     nyaUser.subjects = ['english', 'physics', 'chemistry'];
    //    nyaUser.passedout = true;
       nyaUser.save();

        // users.push(req.body);
        
        console.log(req.body);
        res.json({
            success:true
        })
    })
    
    // app.get('/', (req, res)=>{
    //      res.sendfile('server/website/index.html')
    // });
//     app.get('/56.jpg', (req, res)=>{
//         res.sendfile('server/website/56.jpg')
//    });


    app.use(express.static('server/build'));
    app.use(express.static('server/hello'));

    app.listen(process.env.PORT || 6070, ()=>{
        console.log('server chal parign')
    })