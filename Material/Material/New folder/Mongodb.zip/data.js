function makeBiryani(){
    console.log("biryani is baning");
}

function makeRaita(){
    console.log("raita is baning");
}

module.exports = {
    makeBiryani,
    makeRaita
};