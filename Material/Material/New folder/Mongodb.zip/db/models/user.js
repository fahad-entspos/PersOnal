
let mongoose = require('mongoose');

let userSchema = mongoose.Schema({
    name:String,
    age:Number,
    subjects:[String],
    passedout:Boolean,
    joinedOn:Date
});

let User = mongoose.model('abc', userSchema);

module.exports = User;
