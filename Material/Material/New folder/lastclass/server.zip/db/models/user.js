


let mongoose = require('mongoose');

let userSchema = mongoose.Schema({
    type:String, 
    name:String,
    password:String,
    file:String,
    email:String    
});

module.exports = mongoose.model('abc', userSchema);


