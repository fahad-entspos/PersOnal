


let mongoose = require('mongoose');

let adSchema = mongoose.Schema({
    description:String, 
    name:String,
    price:Number,
    file:String,
    userID:String     
});

module.exports = mongoose.model('ad', adSchema);


