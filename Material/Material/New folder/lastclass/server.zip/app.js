    let express = require('express');

    let mongoose = require('mongoose');

    let User =  require('./db/models/user');
    let Ad =  require('./db/models/ad');

    mongoose.connect('mongodb://localhost:27017/studentWaliDB', (err, connection)=>{

    if(connection){


        console.log("DB chal paring");

    //     let nyaUser = new User();
    //     nyaUser.name = "faizan";
    //     nyaUser.age = 20;
    //     nyaUser.subjects = ['english', 'physics', 'chemistry'];
    //    nyaUser.passedout = true;
    //    nyaUser.save();
       

    }else{
        console.log("msla wa");
    }



    });







    let app = express();
    app.use(express.json());


    let jsonwebtoken = require('jsonwebtoken');


    let fs = require('fs');

    // fs.existsSync()

    // fs.writeFile('server/cat.txt', "mioon", (err)=>{
    //     console.log(err);
    // })

    // fs.unlink("server/build.zip", (err)=>{
    //     console.log(err);
    // })

// fs.mkdir("server/testing", (err, data)=>{
//     console.log(err || data);

// });


    const multer  = require('multer');

    const storage = multer.diskStorage({
        destination: function (req, file, cb) {

            let destination  = "server/hello/"+req.body.name;

          let folderH =   fs.existsSync(destination);

            if(folderH){

                cb({message:"User already h"}, null)

            }else{

                fs.mkdir(destination, (err)=>{

                    cb(null, destination)
    
                })


            }

        
       },
        filename: function (req, file, cb) {          
          cb(null, file.originalname)
        }
      })
      
      const upload = multer({ storage: storage })
      

      const adStorage = multer.diskStorage({
        destination: function (req, file, cb) {

            cb(null, 'server/hello/'+req.body.userKaName)


        
       },
        filename: function (req, file, cb) {          
          cb(null, file.originalname)
        }
      })
      
      const     adUpload = multer({ storage: adStorage })

    
    let users = [];

    app.get('/session-check-karo', async (req, res)=>{

        try{

            let data = await jsonwebtoken.verify(req.query.tk, "FSD m cat says mioon")

            let user = await User.findById(data.id);

            // let user = users.find(user=>user.id == data.id);
            
            res.json(user);
        }catch(e){
            res.json(null);
        }

        


    });
    
    app.post('/login', async (req, res)=>{

       let user =  await User.findOne(req.body);

                if(user){

                jsonwebtoken.sign({
                    id:user._id
                },"FSD m cat says mioon", {
                    expiresIn:"2h"
                }, (err, meraToken)=>{


                    res.json({
                        token:meraToken,
                        meraUser:user
                    });



                })

            }else{
                res.json(null);
            }


    });

    app.get('/users-lao', async (req, res)=>{
        
let users = await User.find();
        
        res.json(users);
        
    })
    // REST API
    // axios.get()
    // axios.put()
    // axios.delete()
    
    // new user bnanna h
    // let user = new User()
    // user.save()

    // select * from users
    // saarey users
    // let users = User.find();

    // let users = User.find({city:"FSD"});
    // let users = User.find({$or:[ {name:"FSD"}, {name:"LHR"} ] });
    // let users = User.find({$gt:{age:25}});




    app.get('/ads-lao', async(req, res)=>{

        let ads = await Ad.find();
        res.json(ads);

    });

  

    app.get('/single-ad', async(req, res)=>{

        let ads = await Ad.findById(req.query.id);
        res.json(ads);

        

    });

    app.get('/loads-ads', async(req, res)=>{

        let ads = await Ad.find({userID:req.query.userKiId});
        res.json(ads);

        

    });


    app.post('/create-ad', adUpload.single('file'), async(req, res)=>{

        req.body.file = req.body.userKaName+'/'+req.file.originalname;

        let nyaAd = new Ad(req.body);
        await nyaAd.save()



    });

    app.get('/user-find-karo', async (req, res)=>{

        let userMilgya = await User.findOne({name:req.query.name});

        // let userMilgya =  users.find(function(user, index){

        //     if(user.name == req.query.name){                 
        //          return true;
        //      }
 
        //  });

         res.json(userMilgya);

    })

    app.put('/user-update-karo', async (req, res)=>{

        try{

            
            await User.findByIdAndUpdate(req.body._id, req.body);
            
            res.json({
                success:true
            })
        }catch(e){
            res.json(e);
        }

        // let milgya = users.findIndex(user=>user.id == req.body.id);
        // users[milgya] = req.body;

    })
    
    app.delete('/delete-karo', async (req, res)=>{
      
await User.findByIdAndDelete(req.query.meraIndex)

        // users.splice(  req.query.meraIndex, 1);

        res.json({
            success:true
            }
        )

        console.log("deeted")
    });
    
    app.post('/signup-karo',upload.single('file') , (req, res)=>{
        


        let nyaUser = new User(req.body);

        nyaUser.save();

    //     nyaUser.name = "faizan";
    //     nyaUser.age = 20;
    //     nyaUser.subjects = ['english', 'physics', 'chemistry'];
    //    nyaUser.passedout = true;
    //    nyaUser.save();

        // users.push(req.body);
        
        console.log(req.body);
        res.json({
            success:true
        })
    })
    
    // app.get('/', (req, res)=>{
    //      res.sendfile('server/website/index.html')
    // });
//     app.get('/56.jpg', (req, res)=>{
//         res.sendfile('server/website/56.jpg')
//    });


    app.use(express.static('server/build'));
    app.use(express.static('server/hello'));

    app.listen(process.env.PORT || 6070, ()=>{
        console.log('server chal parign')
    })