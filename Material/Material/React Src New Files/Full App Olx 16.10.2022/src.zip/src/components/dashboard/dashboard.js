import './dashboard.css';


export default (props)=>{

    return <div>
        <table>
            {
                props.myJobs.filter(function(job){

                    if(job.userID == props.cu.id){
                        return true;
                    }

                }).map((job)=>{
                    return <tr>
                        <td>{job.title}</td>
                        <td>{job.specs}</td>
                        <td>{job.salary}</td>
                    </tr>
                })
            }
        </table>
    </div>

}