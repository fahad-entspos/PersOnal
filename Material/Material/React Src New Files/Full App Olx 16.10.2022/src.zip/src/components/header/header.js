import { Link, useNavigate } from "react-router-dom";



export let cities = ['FSD','lHR'];


export default function Header(props){

  let navigate = useNavigate();

    let name = "Khurram";
  
    function hello(){
      alert("hi g");
    }
  
    return <nav>
    <div class="nav-wrapper">
      <a href="#" class="brand-logo">Logo, {props.cu.name ? "Welcome" : ""}, {props.cu.name} </a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><Link to="/abc">Signup</Link></li>
        <li><Link to="/login">Login</Link></li>
        <li><Link to="/users">Admin</Link></li>
        <li><Link to="/post-job">Post Job</Link></li>
        <li><Link to="/jobs">Show Jobs</Link></li>
        <li><span onClick={()=>{
          
          props.setCurrentUser({});
          navigate('/login')


        }}>Logout</span></li>
      </ul>
    </div>
  </nav>
  
  }