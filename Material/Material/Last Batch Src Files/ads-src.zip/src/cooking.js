export function makeBiryani(){

    console.log("biryani is banning");

}

export default ["rameez", "khurram"];