import GoogleMapReact from 'google-map-react';
import { useEffect, useState } from 'react';


function Baloon(){

    return <img width="40" src="marker.png" />

}

export default ()=>{


    let [position, setPosition] = useState({
        lat:0,
        lng:0
    })

    let [data, setData] = useState({
        loaded:true,
        center: {
          lat: 59.95,
          lng: 30.33
        },
        zoom: 11
      });


      useEffect(()=>{

        

        navigator.geolocation.getCurrentPosition((cords)=>{

            // console.log(cords.coords);

            
        //    setData({
        //        loaded:true,
        // })

            setData({
                loaded:true,
                center: {
                    lat: cords.coords.latitude,
                    lng: cords.coords.longitude
                  },
                  zoom: 11
            })

        }, ()=>{
            alert("masla bangya")
        });

      }, []);

    return  <div style={{ height: '100vh', width: '100%' }}>
    {data.loaded  ? 
    <GoogleMapReact
    onClick={(data)=>{  

        setPosition({
            lat:data.lat,
            lng:data.lng
        })

        console.log(data)


    }}
      bootstrapURLKeys={{ key: ""}}
    //   defaultCenter={data.center}
    center={data.center}
      defaultZoom={data.zoom}

    >

        <Baloon lat={position.lat} lng={position.lng} />

      {/* <AnyReactComponent
        lat={59.955413}
        lng={30.337844}
        text="My Marker"
      /> */}
    </GoogleMapReact>

: null}
  </div>

}