import { useEffect, useState } from "react";
import { useSelector } from "react-redux"
import Ad from '../ad/ad';
import axios from "axios";

export default ()=>{

    let [ads, setAds] = useState([])

    useEffect(()=>{

        async function loadAds(){

            let resp = await axios.get('/ads-lao');
            setAds(resp.data);

        }

        loadAds();
            
        // axios.get('/ads-lao').then((resp)=>{

        //     setAds(resp.data);


        // })

    }, [])

    // let ads =  useSelector((store)=>{
    //     return store.adReducer.ads;
    // });

    return <div className="flex">
        {
            ads.map((ad)=>{
                return <Ad {...ad} />;
            })
        }

    </div>


}