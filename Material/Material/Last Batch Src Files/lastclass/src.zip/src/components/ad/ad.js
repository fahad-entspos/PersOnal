import './ad.css';
import store from '../../store/store';
import { useSelector } from 'react-redux';
import {Link} from 'react-router-dom';

export default (props)=>{

let user = useSelector((store)=>{
    return store.userReducer.currentUser;
});

    return <Link to={"/details/"+props._id}>
    
    <div className="ad">
        <img src={props.file} />
        <h4>{props.name} {props.price}</h4>
        
        {user && user._id == props.userID && <button onClick={()=>{

        store.dispatch({
            type:"AD_DELETED",
            id:props.id
        });

        }}>Delete</button> }

        </div>

        </Link>
}