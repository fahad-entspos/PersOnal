import axios from "axios";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import Ad from "../ad/ad";



export default ()=>{

    let [ads, setAds] = useState([])

    let user = useSelector((store)=>{
        return store.userReducer.currentUser;
    })

    useEffect(()=>{

        if(user){
            axios.get('/loads-ads?userKiId='+user._id).then((resp)=>{

                setAds(resp.data);

            });
    }

    }, [user]);

    let state = useSelector((store)=>{
        return store.userReducer.state;
    });

    return state == "loaded" ? <div className="flex">
    {
        ads.map((ad)=>{
            return <Ad {...ad} />;
        })
    }

</div>
: null

}