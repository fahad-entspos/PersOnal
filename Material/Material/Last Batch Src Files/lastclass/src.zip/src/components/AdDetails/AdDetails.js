import axios from "axios";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom"

export default ()=>{

    let [ad, setAd] = useState({})
    let params = useParams();

    useEffect(()=>{

        axios.get('/single-ad?id='+params.adID).then((resp)=>{
            
            setAd(resp.data)

        })

    })

    return <div className="flex">

        <div>
            <img src={'/'+ad.file}  />
        </div>

        <div>
            <h1>{ad.name}</h1>     
            <h1>{ad.price}</h1>
        </div>
        <p>{ad.description}</p>


    </div>

}