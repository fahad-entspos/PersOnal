import { useSelector } from 'react-redux';
import {Navigate} from 'react-router-dom';


export default(props)=>{

    let reducer = useSelector((store)=>{
        return store.userReducer;
    })

    return (

        reducer.state == "loaded" ? localStorage.getItem('someToken') && reducer.currentUser.type == "admin" ? props.children :  reducer.currentUser.type != "admin"  ? <Navigate  to="/dashboard" /> : <Navigate  to="/login" /> : reducer.state == "session_failed" ? <Navigate  to="/login" /> : null
    )
    

}