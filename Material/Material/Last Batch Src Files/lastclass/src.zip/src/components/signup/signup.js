import { useRef } from "react";
import {useForm, } from 'react-hook-form';
import {useNavigate} from 'react-router-dom';
import store from '../../store/store';
import axios from 'axios';
import {toast} from 'react-toastify'

export default (props)=>{

    let navigate = useNavigate();
    
    let data = useForm();
    
    
    async function saveUser(meraData){

        let form = new FormData();        
        form.append("name",meraData.name)
        form.append("email",meraData.email)
        form.append("password",meraData.password)
        form.append("file",meraData.file[0])

        // {
        //     name:"khurram"
        // }

        meraData.file = meraData.file[0]

        // meraData.id = Math.round(Math.random() * 1000);

        // store.dispatch({
        //     type:"User_ADDED",
        //     payload:meraData
        // });

        console.log(meraData);    
          

        try{
               let resp = await axios.post('/signup-karo', form);
               toast.success("user bangya wa");
        }
        catch(e){
            toast.error("User already h")
            console.log(e);
        }



        // axios.put('/signup-karo', meraData);

        // get aur delete m data nahi jyega


        // data.reset();
        // navigate('/login')
    

    }

    return <div>
        <form onSubmit={data.handleSubmit( saveUser  )}>
            <div>
                <input {...data.register('name', {required:true})} />
            </div>
            {data.formState.errors.name && <div className="error">name btyen</div>}
            
            <div>
                <input {...data.register('email', {required:true})} />
            </div>
            {data.formState.errors.email && <div className="error">email btyen</div>}

        
            <div>
                <input {...data.register('password', {required:true})}/>
            </div>
            {data.formState.errors.password && data.formState.errors.password.type == "required" && <div className="error">password btyen</div>}
            {data.formState.errors.password && data.formState.errors.password.type == "minLength" &&<div className="error">password ki min length 6 h</div>}
            {data.formState.errors.password && data.formState.errors.password.type == "validate" &&<div className="error">Aik capital letter bhi type kren</div>}

            <div>
                <input type="file" {...data.register('file', {required:true})}/>
            </div>


        <button>Submit</button>
        </form>

    </div>

}