import axios from "axios";
import { useRef } from "react";
import {useForm, } from 'react-hook-form';
import { useSelector } from "react-redux";
import {useNavigate} from 'react-router-dom';
import store from '../../store/store';

export default (props)=>{

    let navigate = useNavigate();
    
    let data = useForm();

    let user = useSelector((store)=>{
        return store.userReducer.currentUser;
    })
    
    
    async function saveUser(meraData){

        let form = new FormData();        
        form.append("name",meraData.name)
        form.append("price",meraData.price)
        form.append("description",meraData.description)
        form.append("userKaName",user.name);
        form.append("userID",user._id);

        
        form.append("file",meraData.picture[0])

        // meraData.picture = URL.createObjectURL(meraData.picture[0]);

        // meraData.id = Math.round(Math.random() * 1000);

    // meraData.userID = 

        await axios.post('/create-ad', form)

        // store.dispatch({
        //     type:"CREATED_AD",
        //     payload:meraData
        // });


        data.reset();
       
    

    }

    return <div>
        <form onSubmit={data.handleSubmit( saveUser  )}>
            <div>
                <input placeholder="Name" {...data.register('name', {required:true})} />
            </div>
            {data.formState.errors.name && <div className="error">name btyen</div>}
            
            <div>
                <input placeholder="Price" {...data.register('price', {required:true})} />
            </div>
            {data.formState.errors.price && <div className="error">Price btyen</div>}
 
            <div>
                <input placeholder="Description" {...data.register('description', {required:true})} />
            </div>
            {data.formState.errors.description && <div className="error">Price btyen</div>}

            <div>
                <input multiple type="file" {...data.register('picture', {required:true})} />
            </div>
            {data.formState.errors.picture && <div className="error">Picture btyen</div>}

        
            

        <button>Submit</button>
        </form>

    </div>

}