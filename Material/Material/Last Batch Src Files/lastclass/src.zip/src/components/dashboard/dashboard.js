
import axios from "axios";
import { useEffect, useState } from "react"
import { useSelector } from "react-redux"
import { Link, useParams } from "react-router-dom"
export default (props)=>{

    let [users, setUsers] = useState([]);

    useEffect(async ()=>{

        let resp = await axios.get('/users-lao');
        

        console.log(resp.data);
        setUsers(resp.data);

    }, []);

    useEffect(()=>{

        
    }, [])

    // let users = useSelector(function(store){
    //     return store.userReducer.users;
    // });

    // let myParams = useParams();
    // myParams.user

    return <div>
            <table>
                {
                    users.map((user, index)=>{
                        return <tr>
                            <td>{user.name}</td>
                            <td>{user.email}</td>
                            <td>{user.password}</td>
                            <td>
                                <button onClick={async()=>{

                                    let resp = await axios.delete('/delete-karo?meraIndex='+user._id)

                                    if(resp.data.success){
                                        users.splice(index, 1);
                                        setUsers([...users]);   
                                    }


                                }}>Delete</button>
                            </td>
                            <td>
                                <Link to={"/edit/"+user.name}>Edit</Link>
                            </td>
                        </tr>
                    })
                }
                </table>
        </div>

}