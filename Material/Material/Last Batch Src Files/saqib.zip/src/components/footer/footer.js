import './footer.css';

export function Footer(){

    return <footer>
      <h1>Yeh footer hogya</h1>
    </footer>
  }