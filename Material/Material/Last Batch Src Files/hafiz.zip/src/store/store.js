import {createStore, combineReducers} from 'redux';

let meraOlDData = {
    users:["rameez", "hamid"]
}


function userSection(oldData = meraOlDData, newData){

    if(newData.type == "User_ADDED"){
        oldData.users.push(newData.acc);
    }else if(newData.type == "USER_DELETED"){
        oldData.users.splice(newData.someIndex, 1);
    }

    return {...oldData};

}

function adSection(oldData, newData){

    return ["OPPO10", "HP650"]

}

let root = combineReducers({userSection, adSection});

let meraStore = createStore(root);

export default meraStore;