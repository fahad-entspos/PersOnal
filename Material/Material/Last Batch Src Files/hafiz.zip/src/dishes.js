export function makeTikka(){

    console.log("tikka is banning");

}


export let dishes = ["biryani", "haleem"];

export default function makeRaita(){
    
    console.log("raita is banning");

}